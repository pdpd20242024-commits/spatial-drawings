"""Read evaluated visible Grease Pencil strokes without modifying the scene."""
import bpy,json,os
import numpy as np
scene=bpy.context.scene
depsgraph=bpy.context.evaluated_depsgraph_get()
blocks=[];objects=[];strokes=[];cursor=0;sid=0
for obj in scene.objects:
 if obj.type!='GREASEPENCIL' or not obj.visible_get() or obj.hide_render:continue
 e=obj.evaluated_get(depsgraph);scale=e.matrix_world.to_scale()
 if max(scale)-min(scale)>1e-5:raise RuntimeError('Nonuniform object scale requires explicit radius handling')
 role='background' if '\u80cc\u666f' in obj.name else 'ink'
 oid='object-%03d'%len(objects);objects.append({'id':oid,'role':role})
 for li,layer in enumerate(e.data.layers):
  f=layer.current_frame()
  if layer.hide or not f:continue
  d=f.drawing;n=len(d.attributes['position'].data)
  if not n:continue
  pos=np.empty(n*3,dtype=np.float32);d.attributes['position'].data.foreach_get('vector',pos);pos=pos.reshape(-1,3)
  matrix=np.array(e.matrix_world,dtype=np.float64);pos=pos@matrix[:3,:3].T+matrix[:3,3]
  def scalar(name,default):
   a=d.attributes.get(name)
   if not a:return np.full(n,default,dtype=np.float32)
   x=np.empty(n,dtype=np.float32);a.data.foreach_get('value',x);return x
  radius=scalar('radius',.01)*scale[0];opacity=scalar('opacity',1)*layer.opacity
  vc=np.zeros((n,4),dtype=np.float32)
  if d.attributes.get('vertex_color'):d.attributes['vertex_color'].data.foreach_get('color',vc.ravel())
  offset=0
  for ci,st in enumerate(d.strokes):
   count=len(st.points);sl=slice(offset,offset+count);offset+=count
   if count<2:continue
   a=d.attributes.get('curve_type');ct=int(a.data[ci].value) if a else 1
   if ct!=1:raise RuntimeError('This export expects evaluated polyline strokes')
   mat=e.data.materials[st.material_index] if st.material_index<len(e.data.materials) else None
   base=np.array(mat.grease_pencil.color if mat and mat.is_grease_pencil else [0,0,0,1],dtype=np.float32)
   color=vc[sl,:3]*vc[sl,3:4]+base[:3]*(1-vc[sl,3:4])
   alpha=opacity[sl]*base[3]
   block=np.column_stack((pos[sl],radius[sl],color,alpha)).astype('<f4')
   blocks.append(block);strokes.append({'id':'stroke-%05d'%sid,'object':oid,'layer':li,'start':cursor,'count':count,'cyclic':bool(st.cyclic),'role':role});cursor+=count;sid+=1
allpoints=np.concatenate(blocks)
root=globals().get('EXPORT_DIRECTORY','/tmp/hand-web-export');os.makedirs(root,exist_ok=True)
allpoints.tofile(root+'/hand.points.bin')
spaces=[a.spaces.active for a in bpy.context.screen.areas if a.type=='VIEW_3D']
view={'quaternion':list(spaces[0].region_3d.view_rotation)} if spaces else {}
meta={'format':'spatial-strokes-binary','version':1,'name':'Hand Study','sourceFrame':scene.frame_current,'coordinates':{'up':'Z','space':'world','unit':'Blender unit'},'colorSpace':'linear-srgb','layout':['x','y','z','radius','r','g','b','alpha'],'pointCount':cursor,'objects':objects,'strokes':strokes,'bounds':{'min':allpoints[:,:3].min(axis=0).tolist(),'max':allpoints[:,:3].max(axis=0).tolist()},'view':view}
with open(root+'/hand.strokes.json','w') as f:json.dump(meta,f,separators=(',',':'))
print(json.dumps({'objects':len(objects),'strokes':sid,'points':cursor,'bytes':allpoints.nbytes,'bounds':meta['bounds'],'alphaRange':[float(allpoints[:,7].min()),float(allpoints[:,7].max())]}))
