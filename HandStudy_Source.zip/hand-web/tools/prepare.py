"""Build a standalone HTML file and an upload-ready ZIP."""
from pathlib import Path
import base64,json,zipfile
root=Path(__file__).resolve().parent.parent
meta=json.loads((root/'data/hand.strokes.json').read_text())
raw=(root/'data/hand.points.bin').read_bytes()
js='window.SPATIAL_ARTWORK='+json.dumps(meta,separators=(',',':'))+';\nwindow.SPATIAL_POINTS="'+base64.b64encode(raw).decode()+'";\n'
(root/'artwork-data.js').write_text(js)
html=(root/'index.html').read_text().replace('<link rel="stylesheet" href="style.css">','<style>'+(root/'style.css').read_text()+'</style>').replace('<script src="artwork-data.js"></script>','<script>'+js+'</script>').replace('<script src="viewer.js"></script>','<script>'+(root/'viewer.js').read_text()+'</script>')
(root/'HandStudy.html').write_text(html)
with zipfile.ZipFile(root.parent/'HandStudy_Upload.zip','w',zipfile.ZIP_DEFLATED) as z:z.writestr('index.html',html)
print('Upload ZIP ready:',(root.parent/'HandStudy_Upload.zip').stat().st_size,'bytes')
