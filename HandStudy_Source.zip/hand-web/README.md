# Hand Study

A standalone spatial-stroke viewer exported from the current Blender pose.

## Upload

Upload `HandStudy_Upload.zip` directly to Netlify. Its root contains `index.html`, including all artwork data and display code. No external network dependencies, build process, or server backend is required.

For local viewing, open `HandStudy.html` in a WebGL 2 browser. The editable multi-file entry is `index.html`.

## Controls

Drag to orbit. Wheel to zoom. Right-drag or Shift-drag to pan. Touch: one finger orbits, two fingers zoom and pan. Arrow keys orbit; Home resets.

The four buttons reset the view, toggle auto rotation, toggle the floor, and enter fullscreen. The floor is generated in the browser and is not part of the exported artwork.

## Artwork

23 visible Grease Pencil objects, 1,399 strokes, 164,531 points. Static snapshot of the current scene at frame 1, during the complete-work introduction. The Blender scene is unchanged. No animation or audio is included.

The source retains ordered stroke points, per-point radius, effective linear RGB and opacity, object grouping, and closed/open flags. No stroke mesh or GLB conversion is stored. The GPU generates temporary screen-facing stroke segments only for display.

`data/hand.strokes.json` describes the format and stroke boundaries. `data/hand.points.bin` is a little-endian Float32 buffer with eight components per point: x, y, z, radius, r, g, b, alpha. Positions and radii are in world space. Exported object and stroke identifiers use English/ASCII only. Blender source names and weight attributes are not included.

Background-role strokes are displayed in pure white to match the page; their exported original effective RGB remains in the binary source. Ink colors are converted from linear RGB to display sRGB. Multisample alpha coverage handles opacity and line edges; this is an approximation for semitransparent overlap, not a full reproduction of Blender's transparency compositor.

## Updating

Run `tools/export_blender.py` in Blender with the desired scene and frame active. It reads evaluated visible polyline Grease Pencil objects and writes to `/tmp/hand-web-export` by default. Copy the resulting two files into `data/`. Run `python3 tools/prepare.py` to rebuild embedded data, the standalone page, and upload ZIP.

The current exporter intentionally rejects unsupported curve types and nonuniform object scale. Materials are reduced to effective stroke base/vertex color and opacity; texture, fill and special blend effects are not reproduced. The current model uses polyline strokes. Clipping of segments intersecting the camera near plane is not yet supported.

No Chinese text is included in this project's source or interface. No external CDN, analytics, fonts, or other network services are used.
