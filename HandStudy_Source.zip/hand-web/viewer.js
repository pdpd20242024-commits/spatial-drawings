// Source remains ordered strokes + Bezier handles. Quads below exist only on the GPU.
const canvas=document.querySelector('#art'),status=document.querySelector('#status');
const gl=canvas.getContext('webgl2',{antialias:true,alpha:false,preserveDrawingBuffer:true});
const fail=e=>{status.textContent='Unable to display artwork: '+e.message;console.error(e)};
const add=(a,b)=>a.map((v,i)=>v+b[i]),sub=(a,b)=>a.map((v,i)=>v-b[i]),mul=(a,s)=>a.map(v=>v*s),dot=(a,b)=>a.reduce((v,x,i)=>v+x*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>mul(a,1/(Math.hypot(...a)||1));
const srgb=v=>v<=.0031308?12.92*v:1.055*Math.pow(Math.max(0,v),1/2.4)-.055;
function sample(data){
 const buffer=Uint8Array.from(atob(window.SPATIAL_POINTS),c=>c.charCodeAt(0)).buffer;
 const points=new Float32Array(buffer),segments=[];
 if(points.length!==data.pointCount*8)throw Error('Point buffer length mismatch');
 for(const s of data.strokes){for(let j=0;j<s.count-(s.cyclic?0:1);j++){
 const ai=(s.start+j)*8,bi=(s.start+(j+1)%s.count)*8;
 if(Math.hypot(points[ai]-points[bi],points[ai+1]-points[bi+1],points[ai+2]-points[bi+2])<1e-10)continue;
 if(points[ai+3]<=0&&points[bi+3]<=0)continue;
 segments.push(...points.subarray(ai,ai+4),...points.subarray(bi,bi+4));
 for(const i of [ai,bi])segments.push(s.role==='background'?1:srgb(points[i+4]),s.role==='background'?1:srgb(points[i+5]),s.role==='background'?1:srgb(points[i+6]),points[i+7]);
 }}return {array:new Float32Array(segments),count:segments.length/16,renderedPoints:data.pointCount};
}
const vs=`#version 300 es
precision highp float;
layout(location=0) in vec4 pointA;layout(location=1) in vec4 pointB;layout(location=2) in vec4 colorA;layout(location=3) in vec4 colorB;
uniform vec3 eye,right,up,forward;uniform vec2 viewport;uniform float focal,nearPlane,farPlane;
flat out vec2 A;flat out vec2 B;flat out vec2 radii;flat out vec2 depths;flat out vec4 ca;flat out vec4 cb;
float depth(float z){return (farPlane+nearPlane)/(farPlane-nearPlane)-2.*farPlane*nearPlane/((farPlane-nearPlane)*z);}
void main(){vec3 pa=pointA.xyz-eye,pb=pointB.xyz-eye;float za=dot(pa,forward),zb=dot(pb,forward);if(min(za,zb)<=nearPlane){gl_Position=vec4(2.,2.,2.,1.);return;}
 A=vec2(dot(pa,right),dot(pa,up))*focal/za+viewport*.5;B=vec2(dot(pb,right),dot(pb,up))*focal/zb+viewport*.5;
 radii=vec2(pointA.w*focal/za,pointB.w*focal/zb);depths=vec2(depth(za),depth(zb));ca=colorA;cb=colorB;
 vec2 lo=min(A,B)-max(radii.x,radii.y)-2.,hi=max(A,B)+max(radii.x,radii.y)+2.;
 vec2 corners[6]=vec2[6](vec2(0,0),vec2(1,0),vec2(0,1),vec2(0,1),vec2(1,0),vec2(1,1));vec2 p=mix(lo,hi,corners[gl_VertexID]);gl_Position=vec4(p/viewport*2.-1.,0.,1.);}`;
const fs=`#version 300 es
precision highp float;flat in vec2 A;flat in vec2 B;flat in vec2 radii;flat in vec2 depths;flat in vec4 ca;flat in vec4 cb;out vec4 result;
void main(){vec2 ab=B-A;float t=clamp(dot(gl_FragCoord.xy-A,ab)/max(dot(ab,ab),.00001),0.,1.);float r=mix(radii.x,radii.y,t);float d=length(gl_FragCoord.xy-mix(A,B,t));float coverage=1.-smoothstep(r-.65,r+.65,d);vec4 c=mix(ca,cb,t);if(r<=0.||coverage*c.a<.01)discard;result=vec4(c.rgb,c.a*coverage);gl_FragDepth=mix(depths.x,depths.y,t)*.5+.5;}`;
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
const floorVS=`#version 300 es
precision highp float;
void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));gl_Position=vec4(p*2.-1.,1.,1.);}`;
const floorFS=`#version 300 es
precision highp float;uniform vec3 eye,right,up,forward,center;uniform vec2 viewport;uniform float focal,nearPlane,farPlane,ground,spacing,extent;out vec4 result;
void main(){vec2 uv=(gl_FragCoord.xy-viewport*.5)/focal;vec3 ray=forward+uv.x*right+uv.y*up;if(abs(ray.z)<.00001)discard;float t=(ground-eye.z)/ray.z;if(t<=nearPlane||t>=farPlane)discard;vec3 p=eye+ray*t;float fade=1.-smoothstep(extent*.25,extent,length(p.xy-center.xy));if(fade<=0.)discard;
vec2 c=(p.xy-center.xy)/spacing;vec2 w=max(fwidth(c),vec2(.00001));vec2 line=abs(fract(c-.5)-.5)/w;float grid=1.-smoothstep(.35,1.05,min(line.x,line.y));vec3 color=mix(vec3(1),vec3(.84),grid*fade*.62);result=vec4(color,1);float z=dot(p-eye,forward);gl_FragDepth=((farPlane+nearPlane)/(farPlane-nearPlane)-2.*farPlane*nearPlane/((farPlane-nearPlane)*z))*.5+.5;}`;
async function main(){if(!gl)throw Error('WebGL 2 is required');const data=window.SPATIAL_ARTWORK;if(data.format!=='spatial-strokes-binary'||data.version!==1)throw Error('Unsupported stroke format');
 const sampled=sample(data),program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
 const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,sampled.array,gl.STATIC_DRAW);for(let i=0;i<4;i++){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,4,gl.FLOAT,false,64,i*16);gl.vertexAttribDivisor(i,1)}
 const U=Object.fromEntries(['eye','right','up','forward','viewport','focal','nearPlane','farPlane'].map(k=>[k,gl.getUniformLocation(program,k)]));
 const center=mul(add(data.bounds.min,data.bounds.max),.5),diameter=Math.hypot(...sub(data.bounds.max,data.bounds.min));let target=[...center],yaw=-.1,pitch=.22,distance=diameter*1.15,auto=false,dirty=true,last=0;
 // Match Blender viewport orientation at startup, but frame around the artwork itself.
 const q=data.view?.quaternion;if(q){const [w,x,y,z]=q,back=[2*(x*z+w*y),2*(y*z-w*x),1-2*(x*x+y*y)];yaw=Math.atan2(back[0],-back[1]);pitch=Math.asin(Math.max(-1,Math.min(1,back[2])))}
 distance*=Math.max(1,canvas.clientHeight/Math.max(1,canvas.clientWidth)*.9);const home={yaw,pitch,distance};const reset=()=>{target=[...center];({yaw,pitch,distance}=home);dirty=true};
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);// Coverage and depth use the same multisample mask, including opacity.
 gl.disable(gl.BLEND);gl.enable(gl.SAMPLE_ALPHA_TO_COVERAGE);gl.clearColor(1,1,1,1);
 const floorProgram=gl.createProgram();gl.attachShader(floorProgram,shader(gl.VERTEX_SHADER,floorVS));gl.attachShader(floorProgram,shader(gl.FRAGMENT_SHADER,floorFS));gl.linkProgram(floorProgram);
 if(!gl.getProgramParameter(floorProgram,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(floorProgram));
 const FU=Object.fromEntries(['eye','right','up','forward','viewport','focal','nearPlane','farPlane','ground','spacing','center','extent'].map(k=>[k,gl.getUniformLocation(floorProgram,k)]));let floorVisible=true;
 let basis;function draw(){const dpr=Math.min(devicePixelRatio||1,2),W=Math.round(canvas.clientWidth*dpr),H=Math.round(canvas.clientHeight*dpr);if(canvas.width!==W||canvas.height!==H){canvas.width=W;canvas.height=H}gl.viewport(0,0,W,H);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 const back=[Math.cos(pitch)*Math.sin(yaw),-Math.cos(pitch)*Math.cos(yaw),Math.sin(pitch)],eye=add(target,mul(back,distance)),forward=mul(back,-1),right=norm(cross(forward,[0,0,1])),up=cross(right,forward);basis={right,up};
 for(const [k,v] of Object.entries({eye,forward,right,up}))gl.uniform3fv(U[k],v);gl.uniform2f(U.viewport,W,H);gl.uniform1f(U.focal,H/(2*Math.tan(Math.PI/8)));gl.uniform1f(U.nearPlane,diameter*.001);gl.uniform1f(U.farPlane,diameter*100);
 if(floorVisible){gl.useProgram(floorProgram);for(const [k,v] of Object.entries({eye,forward,right,up}))gl.uniform3fv(FU[k],v);gl.uniform3fv(FU.center,center);gl.uniform2f(FU.viewport,W,H);gl.uniform1f(FU.focal,H/(2*Math.tan(Math.PI/8)));gl.uniform1f(FU.nearPlane,diameter*.001);gl.uniform1f(FU.farPlane,diameter*100);gl.uniform1f(FU.ground,data.bounds.min[2]-diameter*.035);gl.uniform1f(FU.spacing,diameter/15);gl.uniform1f(FU.extent,diameter*2.5);gl.drawArrays(gl.TRIANGLES,0,3);gl.useProgram(program);}
 gl.drawArraysInstanced(gl.TRIANGLES,0,6,sampled.count);dirty=false;}
 function pan(dx,dy){if(!basis)return;const f=2*distance*Math.tan(Math.PI/8)/canvas.clientHeight;target=add(target,add(mul(basis.right,-dx*f),mul(basis.up,dy*f)));dirty=true}
 const pointers=new Map();let gesture;canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});gesture=null});
 canvas.addEventListener('pointermove',e=>{const prev=pointers.get(e.pointerId);if(!prev)return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2){const [a,b]=[...pointers.values()],g={x:(a.x+b.x)/2,y:(a.y+b.y)/2,d:Math.hypot(a.x-b.x,a.y-b.y)};if(gesture){distance*=gesture.d/Math.max(g.d,1);pan(g.x-gesture.x,g.y-gesture.y)}gesture=g}else if(e.buttons===2||e.shiftKey)pan(e.clientX-prev.x,e.clientY-prev.y);else{yaw-=(e.clientX-prev.x)*.006;pitch+=(e.clientY-prev.y)*.006}clamp();dirty=true});
 function clamp(){pitch=Math.max(-1.52,Math.min(1.52,pitch));distance=Math.max(diameter*.06,Math.min(diameter*12,distance))}for(const name of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(name,e=>{pointers.delete(e.pointerId);gesture=null});
 canvas.addEventListener('wheel',e=>{e.preventDefault();distance*=Math.exp(e.deltaY*.001);clamp();dirty=true},{passive:false});canvas.addEventListener('keydown',e=>{if(e.key==='Home'){reset();e.preventDefault()}if(e.key.startsWith('Arrow')){if(e.key==='ArrowLeft')yaw+=.06;if(e.key==='ArrowRight')yaw-=.06;if(e.key==='ArrowUp')pitch-=.06;if(e.key==='ArrowDown')pitch+=.06;clamp();dirty=true;e.preventDefault()}});
 document.querySelector('#reset').onclick=reset;document.querySelector('#rotate').onclick=e=>{auto=!auto;e.currentTarget.setAttribute('aria-pressed',auto)};document.querySelector('#floor').onclick=e=>{floorVisible=!floorVisible;e.currentTarget.setAttribute('aria-pressed',floorVisible);dirty=true};
 document.querySelector('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.querySelector('main').requestFullscreen()}catch(e){fail(e)}};
 new ResizeObserver(()=>dirty=true).observe(canvas);canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();status.textContent='Graphics context lost. Please reload.'});
 window.artworkViewer={data,segmentCount:sampled.count,renderedPoints:sampled.renderedPoints,reset,get state(){return {yaw,pitch,distance,target:[...target]}}};
 status.textContent='';
 function tick(t){if(auto&&!pointers.size){yaw+=Math.min((t-last)/1000,.05)*.17;dirty=true}last=t;if(dirty)draw();requestAnimationFrame(tick)}requestAnimationFrame(tick);
}
main().catch(fail);
